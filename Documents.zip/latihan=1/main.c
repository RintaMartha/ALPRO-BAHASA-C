#include<stdio.h>
#include<conio.h>
main()
{
int i,n,j;
for (i=1;i<=10;i++)
{
    for (j=1;j<=i;j++)
                {
                    printf("*");
                }
        printf("\n");
}
        printf("program selesai");
        printf("\n");
        printf("Rinta Martha Utami - d22.2024.03722");
        printf("\n");
}
