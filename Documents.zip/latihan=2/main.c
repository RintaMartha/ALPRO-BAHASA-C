#include <stdio.h>

int main()
{
    int angka;

    do{
            printf("masukkan sebuah angka (lebih besar dari 10 untuk berhenti): ");
            scanf("%d",&angka);
        }while (angka <= 10); // angka harus lebih besar dari 10, jika < akan repeat until lebih besar

        printf("Terimakasih anda memasukkan %d yang lebih besar dari 10.\n", angka);

    return 0;
}
