#include <stdio.h>
int main() {
    int i = 1;        // penghitung
    int n;            // input dari user
    int jumlah = 0;   // akumulasi jumlah

    do {
        printf("Masukkan angka ke-%d: ", i);
        scanf("%d", &n);

        jumlah += n;  // tambahkan input ke jumlah
        i++;          // naikkan penghitung

    } while (jumlah < 100);

    printf("Penjumlahan berhenti. Total jumlah = %d\n", jumlah);

    return 0;
}
